package com.example.lab08.whatsappuidesign.Model;

/**
 * Created by Lab08 on 30.03.2018.
 */

public class Chat {
    private int userId;
    private int uniqeId;
    private String gonderenMesaj;
    private boolean gonderenKisiSenmisin;
    private String resim;
    public Chat(){}

    public Chat(int userId, int uniqeId, String gonderenMesaj, boolean gonderenKisiSenmisin, String resim) {
        this.userId = userId;
        this.uniqeId = uniqeId;
        this.gonderenMesaj = gonderenMesaj;
        this.gonderenKisiSenmisin = gonderenKisiSenmisin;
        this.resim = resim;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUniqeId() {
        return uniqeId;
    }

    public void setUniqeId(int uniqeId) {
        this.uniqeId = uniqeId;
    }

    public String getGonderenMesaj() {
        return gonderenMesaj;
    }

    public void setGonderenMesaj(String gonderenMesaj) {
        this.gonderenMesaj = gonderenMesaj;
    }

    public boolean isGonderenKisiSenmisin() {
        return gonderenKisiSenmisin;
    }

    public void setGonderenKisiSenmisin(boolean gonderenKisiSenmisin) {
        this.gonderenKisiSenmisin = gonderenKisiSenmisin;
    }
}
