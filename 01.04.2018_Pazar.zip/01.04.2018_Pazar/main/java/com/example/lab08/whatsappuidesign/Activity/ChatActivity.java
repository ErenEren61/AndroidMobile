package com.example.lab08.whatsappuidesign.Activity;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lab08.whatsappuidesign.Model.Chat;
import com.example.lab08.whatsappuidesign.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    ImageView btnSendMessage;
    EditText etMessage;
    LinearLayout linearLayout;
    ArrayList<Chat> mesajlar=new ArrayList<Chat>();

    private void doldur(ArrayList<Chat> mesaj) {
        for (int i = 0; i < mesaj.size(); i++) {

            LinearLayout linear = new LinearLayout(this);
            linear.setOrientation(LinearLayout.VERTICAL);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT

            );

            if (mesaj.get(i).isGonderenKisiSenmisin()) {
                linear.setBackgroundResource(R.color.colorMyTextBackground);
                layoutParams.gravity = Gravity.RIGHT;
            } else {
                linear.setBackgroundResource(R.color.colorSenderTextBackground);
                layoutParams.gravity = Gravity.LEFT;
            }

            layoutParams.setMargins(10, 10, 10, 10);

            TextView tv = new TextView(this);
            tv.setText(mesaj.get(i).getGonderenMesaj());

            tv.setTextColor(Color.parseColor("#FFFFFF"));
            tv.setTextSize(18f);

            layoutParams.setMargins(20, 20, 20, 20);
            tv.setLayoutParams(layoutParams);
            tv.setPadding(10, 10, 10, 10);
            linear.addView(tv);
            if (!mesaj.get(i).getResim().isEmpty()) {
                ImageView iv = new ImageView(this);
                Picasso.with(getApplicationContext()).load(mesaj.get(i).getResim()).into(iv);
                linear.addView(iv);
                iv.setLayoutParams(layoutParams);
            }
            linearLayout.addView(linear, layoutParams);

        }
    }

    private void ekle(String icerik, String resim) {
        LinearLayout linear = new LinearLayout(this);
        linear.setOrientation(LinearLayout.VERTICAL);
        linear.setBackgroundResource(R.color.colorMyTextBackground);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT

        );
        layoutParams.setMargins(10, 10, 10, 10);
        layoutParams.gravity = Gravity.RIGHT;
        TextView tv = new TextView(this);
        tv.setText(icerik);
        tv.setTextColor(Color.parseColor("#FFFFFF"));
        tv.setTextSize(18f);

        LinearLayout.LayoutParams Params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        Params.setMargins(20, 20, 20, 20);
        Params.gravity = Gravity.RIGHT;
        tv.setLayoutParams(Params);
        tv.setPadding(10, 10, 10, 10);
        linear.addView(tv);

        if (!resim.isEmpty()) {
            ImageView iv = new ImageView(this);
            Picasso.with(getApplicationContext()).load(resim).into(iv);
            linear.addView(iv);
            iv.setLayoutParams(layoutParams);
        }
        mesajlar.add(new Chat(1,1,icerik,true,resim));

        linearLayout.addView(linear, Params);

    }

    public void tumMesajlariGetir() {
        mesajlar.add(new Chat(1, 1, "Selam nasılsın", true,""));
        mesajlar.add(new Chat(1, 1, "Naber hacı", true,""));
        mesajlar.add(new Chat(2, 1, "İyiyim  bro sen nasılsın", false,"http://img7.mynet.com/galeri/2016/02/29/115015841/6299874-600x406.jpg"));
        doldur(mesajlar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_chat,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setSubtitle("Çevrimiçi");


        String adSoyad = getIntent().getStringExtra("adsoyad");
        int userId = getIntent().getIntExtra("userid", 0);
        this.setTitle(adSoyad);

        btnSendMessage = findViewById(R.id.btnSendMesaj);
        etMessage = findViewById(R.id.etMesaj);
        btnSendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ekle(etMessage.getText().toString(), "http://img7.mynet.com/galeri/2016/02/29/115015841/6299874-600x406.jpg");
            }
        });


        linearLayout = (LinearLayout) findViewById(R.id.linearLayoutChat);

        tumMesajlariGetir();
    }
}
