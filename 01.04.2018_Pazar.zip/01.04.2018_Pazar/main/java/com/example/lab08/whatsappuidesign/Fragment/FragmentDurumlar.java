package com.example.lab08.whatsappuidesign.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.whatsappuidesign.Adapter.GridViewDurumlarAdapter;
import com.example.lab08.whatsappuidesign.Model.Durumlar;
import com.example.lab08.whatsappuidesign.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Lab08 on 24.03.2018.
 */

public class FragmentDurumlar extends Fragment {

    GridView gridViewDurumlar;
    ImageView ivResim;
    TextView tvAdSoyad;
    TextView tvSonGuncellemeZamani;
    ArrayList<Durumlar> liste = new ArrayList<>();

    private void doldur() {
        liste.add(new Durumlar(1, "Cafer Cafer", "Dün", "http://kaoaz.co/wp-content/uploads/cribbsaw-1080x1080e-1080x1080-home-design-cribbs-9i.png"));
}


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout_durumlar, container, false);


        gridViewDurumlar = (GridView) view.findViewById(R.id.gridViewDurumlar);
        tvAdSoyad = (TextView) view.findViewById(R.id.tvDurumAdSoyad);
        tvSonGuncellemeZamani = (TextView) view.findViewById(R.id.tvDurumGuncellemeTarihi);
        ivResim = (ImageView) view.findViewById(R.id.ivDurumKucukResim);

        tvAdSoyad.setText("Burak KAYA");
        tvSonGuncellemeZamani.setText("10 saat önce");
        Picasso.with(getContext()).load("https://www.madisonfrequency.com/files/2015/07/13741268_533406100192978_1490747636_n.jpg").into(ivResim);

        doldur();

        GridViewDurumlarAdapter adapter = new GridViewDurumlarAdapter(getContext(), liste);
        gridViewDurumlar.setAdapter(adapter);

        return view;
    }
}

